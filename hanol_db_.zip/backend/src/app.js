const express = require('express');
const app = express();
const tablesRoute = require('./routes/tables');

app.use(express.json());

// 샘플 API: /tables
app.use('/tables', tablesRoute);

// 서버 실행
const PORT = process.env.PORT || 3000;
app.listen(PORT, () => {
  console.log(`🚀 서버 실행 중: http://localhost:${PORT}`);
});
