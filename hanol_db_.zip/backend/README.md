# Hanol Backend (Node.js + Express + Railway MySQL)

## 📦 실행 방법

1. 레포지토리 클론하기
```bash
git clone https://github.com/your-username/backend.git
cd backend
```

2. npm 설치
```bash
npm install
```

3. `.env` 파일 만들기
```bash
cp .env.example .env
```

4. `.env` 파일에 Railway DB 정보 입력하기

5. 서버 실행하기 (개발용)
```bash
npm run dev
```

✅ 성공 시: `🚀 서버 실행 중: http://localhost:3000` 라고 뜹니다!

## 📡 샘플 API 테스트

- `GET http://localhost:3000/tables`  
  ➡️ Railway DB의 테이블 목록을 JSON으로 반환합니다.

## 🔒 주의
- `.env` 파일은 절대 깃허브에 올리지 마세요 (`.gitignore`로 무시됨)
